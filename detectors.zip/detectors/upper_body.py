from typing import Tuple, Dict
import cv2
from cv2.typing import MatLike

def detect_upper_body(frame: MatLike, scaleFactor: float = 1.1, minNeighbors: int = 5, minSize: Tuple[int, int] = (30, 30), color: Tuple[int, int, int] = (255, 0, 0), thickness: int = 2, model_path: str = 'C:/Users/admin/Desktop/CSI_Haarcascades/haarcascade_upperbody.xml') -> Tuple[MatLike, Dict[int, Tuple[Tuple[int, int], Tuple[int, int]]]]:
    """
    Detects upper bodies in a given image frame using Haar Cascade classifier and draws rectangles around them.

    Parameters:
        frame: Input image frame.
        scaleFactor: Image size reduction factor.
        minNeighbors: Minimum neighbors to retain detection.
        minSize: Minimum object size to detect.
        color: BGR rectangle color.
        thickness: Rectangle border thickness.
        model_path: Path to Haar cascade XML model.

    Returns:
        Annotated image and dictionary of upper body coordinates.
    """
    model = cv2.CascadeClassifier(model_path)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    upper_bodies = model.detectMultiScale(gray, scaleFactor=scaleFactor, minNeighbors=minNeighbors, minSize=minSize)

    if len(color) != 3:
        raise Exception("Invalid color")

    ret_upper_body = {}

    for i, (x, y, w, h) in enumerate(upper_bodies):
        ret_upper_body[i] = [(int(x), int(y)), (int(x + w), int(y + h))]
        cv2.rectangle(frame, (x, y), (x + w, y + h), color=color, thickness=thickness)

    return frame, ret_upper_body
