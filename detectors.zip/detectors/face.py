from typing import Tuple, Dict
import cv2
from cv2.typing import MatLike

def detect_face(frame: MatLike, scaleFactor: float = 1.1, minNeighbors: int = 5, minSize: Tuple[int, int] = (30, 30), color: Tuple[int, int, int] = (255, 0, 0), thickness: int = 2, model_path: str = '/home/noobscience/temp/example_lib/GRCSI/GRCSI_Harcascade/haarcascade_frontalface_alt.xml') -> Tuple[MatLike, Dict[int, Tuple[Tuple[int, int], Tuple[int, int]]]]:
    """
    Detects faces in a given image frame using Haar Cascade classifier and draws rectangles around them.

    Parameters:
        frame: Input image frame.
        scaleFactor: Parameter specifying how much the image size is reduced at each image scale.
        minNeighbors: Parameter specifying how many neighbors each candidate rectangle should have to retain it.
        minSize: Minimum possible object size. Objects smaller than that are ignored.
        color: Rectangle color in BGR format.
        thickness: Thickness of the rectangle.
        model_path: Path to Haar cascade XML model.

    Returns:
        Annotated image and dictionary of face coordinates.
    """
    model = cv2.CascadeClassifier(model_path)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    faces = model.detectMultiScale(gray, scaleFactor=scaleFactor, minNeighbors=minNeighbors, minSize=minSize)
    
    if len(color) != 3:
        raise Exception("Invalid color")

    ret_face = {}

    for i, (x, y, w, h) in enumerate(faces):
        ret_face[i] = [(int(x), int(y)), (int(x + w), int(y + h))]
        cv2.rectangle(frame, (x, y), (x + w, y + h), color=color, thickness=thickness)

    return frame, ret_face
