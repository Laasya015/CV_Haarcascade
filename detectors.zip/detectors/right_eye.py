from typing import Tuple, Dict
import cv2
from cv2.typing import MatLike

def detect_right_eye(frame: MatLike, scaleFactor: float = 1.1, minNeighbors: int = 10, minSize: Tuple[int, int] = (30, 30), color: Tuple[int, int, int] = (0, 255, 0), thickness: int = 2, model_path: str = 'C:/Users/admin/Desktop/CSI_Haarcascades/haarcascade_righteye_2splits.xml') -> Tuple[MatLike, Dict[int, Tuple[Tuple[int, int], Tuple[int, int]]]]:
    """
    Detects right eyes in a given image frame using Haar Cascade classifier and draws rectangles around them.

    Parameters:
        frame: Input image frame.
        scaleFactor: Parameter specifying how much the image size is reduced at each image scale.
        minNeighbors: Parameter specifying how many neighbors each candidate rectangle should have to retain it.
        minSize: Minimum possible object size. Objects smaller than that are ignored.
        color: Rectangle color in BGR format.
        thickness: Thickness of the rectangle.
        model_path: Path to Haar cascade XML model.

    Returns:
        Annotated image and dictionary of right eye coordinates.
    """
    model = cv2.CascadeClassifier(model_path)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    right_eyes = model.detectMultiScale(gray, scaleFactor=scaleFactor, minNeighbors=minNeighbors, minSize=minSize, flags=cv2.CASCADE_SCALE_IMAGE)

    if len(color) != 3:
        raise Exception("Invalid color")

    ret_right_eye = {}

    for i, (x, y, w, h) in enumerate(right_eyes):
        ret_right_eye[i] = [(int(x), int(y)), (int(x + w), int(y + h))]
        cv2.rectangle(frame, (x, y), (x + w, y + h), color=color, thickness=thickness)

    return frame, ret_right_eye
